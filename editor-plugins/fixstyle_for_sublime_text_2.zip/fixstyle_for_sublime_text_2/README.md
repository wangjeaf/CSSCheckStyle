##ckstyle plugin for Sublime Text 2

### 安装说明
* 找到Sublime Text 2的插件目录，例如：`C:\Documents and Settings\Administrator\Application Data\Sublime Text 2\Packages`
* 将此zip内的内容解压缩到插件目录下即可

### 命令说明

`Fixstyle` 为样式修复
`CssCompress` 为代码压缩

### 使用方法

* Fixstyle快捷键：`alt + tab` ，CssCompress无快捷键

* 菜单项：`tools->Fixstyle`   `tools->CssCompress`

* 右键菜单 `Fixstyle`  `CssCompress`
